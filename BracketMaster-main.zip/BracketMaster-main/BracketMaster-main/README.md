# BracketMaster
An application designed to allow local communities to create, manage and modify tournament brackets.

ALL PIP INSTALLS
pip install virtualenv

env\Scripts\activate

pip install mysql

pip install mysql.connector
pip install sshtunnel
pip install flask flask-sqlalchemy

pip install npm
pip install flask_login
pip install flask_bcrypt
pip install flask_wtf
pip install wtfforms
pip install emailvalidator