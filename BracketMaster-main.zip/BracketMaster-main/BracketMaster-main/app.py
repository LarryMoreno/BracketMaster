from flask import Flask, render_template, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, ValidationError, Email
import main

app = Flask(__name__)
app.config['SECRET_KEY'] = 'thisisasecretkey'

class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(),
        Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    
    password = StringField(validators=[InputRequired(),
        Length(min=4, max=80)], render_kw={"placeholder": "Password"})
    
    email = StringField(validators=[InputRequired(),
        Length(min=10, max=50)], render_kw={"placeholder": "Email"})
    
    submit = SubmitField("Register")

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(),
        Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    
    password = StringField(validators=[InputRequired(),
        Length(min=4, max=80)], render_kw={"placeholder": "Password"})
    
    email = StringField(validators=[InputRequired(),
        Length(min=10, max=50)], render_kw={"placeholder": "Email"})
    
    submit = SubmitField("Login")


@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET','POST'])
def register():
    form = RegisterForm()
    return render_template('register.html', form=form)

if(__name__ == '__main__'):
    app.run(debug=True)


